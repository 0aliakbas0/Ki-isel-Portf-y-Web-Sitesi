document.addEventListener('DOMContentLoaded', function() {
    addScrollAnimation();
    addSmoothScroll();
    initProjectVisitConfirm();
});

function addScrollAnimation() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, {
        threshold: 0.1
    });

    const sections = document.querySelectorAll('.section, .project-card');
    sections.forEach(section => {
        section.style.opacity = '0';
        section.style.transform = 'translateY(20px)';
        section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(section);
    });
}

function addSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href !== '#') {
                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
}

function initProjectVisitConfirm() {
    const modal = document.getElementById('visitConfirm');
    if (!modal) {
        return;
    }

    const confirmBtn = modal.querySelector('[data-confirm]');
    const cancelBtn = modal.querySelector('[data-cancel]');
    const backdrop = modal.querySelector('.confirm-backdrop');
    const buttons = document.querySelectorAll('.ghost-btn[data-url]');
    let pendingUrl = null;

    const showModal = (url) => {
        pendingUrl = url;
        modal.removeAttribute('hidden');
        requestAnimationFrame(() => modal.classList.add('visible'));
    };

    const hideModal = () => {
        modal.classList.remove('visible');
        setTimeout(() => {
            if (!modal.classList.contains('visible')) {
                modal.setAttribute('hidden', '');
            }
        }, 200);
        pendingUrl = null;
    };

    buttons.forEach(btn => {
        btn.addEventListener('click', (event) => {
            event.preventDefault();
            const url = btn.dataset.url;
            if (!url) return;
            showModal(url);
        });
    });

    confirmBtn?.addEventListener('click', () => {
        if (pendingUrl) {
            window.open(pendingUrl, '_blank', 'noopener');
        }
        hideModal();
    });

    [cancelBtn, backdrop].forEach(el => {
        el?.addEventListener('click', hideModal);
    });

    window.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && !modal.hasAttribute('hidden')) {
            hideModal();
        }
    });
}
